function validate()
{
    if (document.getElementById("name").value == "")
    {
        alert("Please provide your name!");
        document.getElementById("name").focus();
        return false;
    }
 
    var eml = document.getElementById('eml').value;
    var l = eml.length;

    atpos = eml.indexOf("@");
    dotpos = eml.lastIndexOf(".");
    if (atpos < 1 || (dotpos - atpos < 2)) {
        alert("Please enter correct email ID");
        var eml = document.getElementById('eml').focus();
        return false;
    }

    var txtbx = document.getElementById("msg").value;
    if (txtbx.length > 20) {
        alert("Messege must be less than 20 character");
    }

}

function cost() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("eml").value;
    var addrs = document.getElementById("adr").value;
    var phone = document.getElementById("phn").value;
    var pcode = document.getElementById("pin").value;

    const w = parseInt(document.getElementById("weight").value);
    const egb = parseInt(document.getElementById("eggless").value);
    
    const price = w + egb;

    alert("\nName: " + name +  
        "\nemail: " + email +
        "\nAddress: " + addrs +
        "\nContact number: " + phone +
        "\nPin code: " + pcode +
        "\nTotal Price: " + price );
}